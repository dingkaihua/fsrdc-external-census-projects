#!/usr/bin/env python3

from publication_apis import *
from score_calculation import *
""" Variables BASE_ID and CORE_ID are defined in helper_funcs and used in publication_apis and api_main """
import sys
import os
from functools import reduce
import datetime
from multiprocessing import Process

# allow imports when running script from within project dir
[sys.path.append(i) for i in ['.', '..']]

# allow imports when running script from project dir parent dirs
l = []
script_path = os.path.split(sys.argv[0])
for i in range(len(script_path)):
  sys.path.append( reduce(os.path.join, script_path[:i+1]) )

def auto_search(db, pjid):
    """ Runs all search queries for a given project id in the given publications API (project title, variations of lead author's name)"""
    # array to hold all the query phrases/words we'll be running
    queries = []
    queries.append(name_and_ds(pjid).get('title'))
    # all names listed as researcher in CMS project
    cms_auts = get_authors(pjid)
    for i in range(len(cms_auts)):
        # all versions of each researcher name to search
        q = aut_queries(cms_auts[i])
        for j in range(len(q)):
            queries.append(q[j])

    if db == BASE_ID:
        api = BaseSearch()
        for i in range(len(queries)):
            results = api.searchAll(pjid, '"' + queries[i] + '"')
            hits = results[1]['response']['numFound']
            if VERBOSE:
                print("'" + queries[i] + "'")
                print("Total hits: " + str(hits))
            # print("proj_id: " +str(results[0]))
            # proj_id = str(results[0])
            # print(results)
            # add hits to JQ Admin database
            if hits > 0:
                api.sendToDBAll(db, pjid, results, hits, VERBOSE)
    if db == CORE_ID:
        api = CoreSearch()
        for i in range(len(queries)):
            results = api.searchAll(pjid, '"' + queries[i] + '"')
            if VERBOSE:
                print("'" + queries[i] + "'")
                print("Total hits: " + str(results[1]['totalHits']))
            # print("proj_id: " +str(results[0]))
            hits = results[1]['totalHits']
            # proj_id = str(results[0])
            if hits is not None:
                api.sendToDBAll(db, pjid, results, hits, VERBOSE)

#Separating this off for time reasons
def run_core_and_base(project_id):
        print(f'Running pull for project id: {project_id} from BASE...')
        auto_search(BASE_ID, project_id)
        print(f'Running pull for project id: {project_id} from CORE...')
        auto_search(CORE_ID, project_id)

#Method to run the pipeline on an individual pjid
def run_pipeline(project_id):
    #tle = Time Limit Exceeded 
    tle = False
    #Sets a 30 minute time limit for BASE and CORE searches
    try:
        p = Process(target=run_core_and_base, args=(project_id,))
        p.start()
        p.join(1800)
        if p.is_alive():
            print("Searches are taking longer than 30 minutes...stopping")
            tle = True
            p.terminate()
            p.join()

        print(f'Removing within-db dupes for project id: {project_id}...')
        remove_dupes(project_id)
        print(f'Updating api_pub_match for project id: {project_id}...')
        update_match_table(project_id, rem_dupes=False)
        print(f'Inputting scores for project id: {project_id}...')
        update_score(project_id)
        print(f'Updating cutoffs for project id: {project_id}...')
        update_cutoffs(project_id)
        print('Success.')
        if tle:
            return True, "Searches are taking longer than 30 minutes...stopping"
        else:
            return True, None
    except Exception as e:
        print(f'Pipeline failed for project id: {project_id}. Reason: {str(e)}')
        return False, str(e)


def run_scheduler(run_today):
    #Connect to the database
    print("Running the scheduler!")
    mydb = mysql.connector.connect(
        host="metahost.census.gov",
        user="username",
        password="password",
        database="metadb"
    )
    mycursor = mydb.cursor()
    #Find all projects with a run_today of 1 and return a list of tuples for each row where each tuple has the project_id
    q1 = f"SELECT project_id FROM pipe_projects WHERE run_today = {run_today}"
    mycursor.execute(q1)
    projects_to_run = mycursor.fetchall()
    if len(projects_to_run) == 0:
        print("No projects found to run right now")
    for project in projects_to_run:
        proj_id = project[0]
        #Determine whether the run was a success or failure
        success, err_message = run_pipeline(proj_id)
        today = datetime.datetime.today().strftime('%Y-%m-%d')
        if success:
            if not err_message is None:
                mycursor.execute(f"INSERT INTO pipe_error (project_id, error_date, error_text) VALUES ({proj_id}, '{today}', %s)", (err_message, ))
                mycursor.execute(f"UPDATE pipe_projects SET run_today = 0, last_run = '{today}' WHERE project_id = {proj_id}")
            else:
                mycursor.execute(f"UPDATE pipe_projects SET run_today = 0, last_run = '{today}' WHERE project_id = {proj_id}")
        else:
            mycursor.execute(f"INSERT INTO pipe_error (project_id, error_date, error_text) VALUES ({proj_id}, '{today}', %s)", (err_message, ))
            mycursor.execute(f"UPDATE pipe_projects SET last_failed = '{today}' WHERE project_id = {proj_id}")
        mydb.commit()
    mydb.close()
    print("Scheduler done running!")

def main(args):
    pipeline = args.pipeline
    #First determine if the static scheduler command should be executed
    if args.scheduler is not None:
        run_scheduler(args.scheduler)
    
    else:
        if args.pjid is None:
            # Grabs all CMS project IDs if no specific project id was specified
            sql_query = f"SELECT DISTINCT project_id FROM api_cms_projects"
            mycursor.execute(sql_query)
            query_resp = mycursor.fetchall()
            cms_project_ids = [query_resp[i][0] for i in range(len(query_resp))]
        else:
            cms_project_ids = args.pjid
        for pjid in cms_project_ids:
            if 0 in pipeline:
                print(f'Running pull for project id: {pjid} from BASE...')
                auto_search(BASE_ID, pjid)
            if 1 in pipeline:
                print(f'Running pull for project id: {pjid} from CORE...')
                auto_search(CORE_ID, pjid)
            if 2 in pipeline:
                print(f'Removing within-db dupes for project id: {pjid}...')
                remove_dupes(pjid)
            if 3 in pipeline:
                print(f'Updating api_pub_match for project id: {pjid}...')
                update_match_table(pjid, rem_dupes=False)
            if 4 in pipeline:
                print(f'Inputting scores for project id: {pjid}...')
                update_score(pjid)
            if 5 in pipeline:
                print(f'Updating cutoffs for project id: {pjid}...')
                update_cutoffs(pjid)
            print('Success.')

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Runs the scoring pipeline for publications',
                                     formatter_class=argparse.RawTextHelpFormatter, add_help=False)
    parser.add_argument('-h', '--help', action='help', default=argparse.SUPPRESS,
                        help='Using --pjid and --pipeline is optional.\nTo run the entire pipeline on '
                             'all CMS project IDs, simply do:\n'
                             'python api_main.py\n')
    parser.add_argument("--pjid", type=int, nargs = '+', help='Input specific CMS project id(s) to run the '
                                            'pipeline on.\nLeaving this empty will run on all CMS projects.\n\n'
                                          'Example call: python api_main.py --pjid 5 \n'
                                          'Example call multiple IDs: python api_main.py --pjid 5 8 189\n')
    parser.add_argument("--pipeline", type=int, default = [0, 1, 2, 3, 4, 5], choices = [0, 1, 2, 3, 4, 5], nargs='+',
                        help='Choose what parts of the pipeline to run. Leaving this empty will run all. \n'
                                                      '0: BASE Search\n'
                                                      '1: CORE Search\n'
                                                      '2: Remove Within-DB Duplicates\n'
                                                      '3: Update api_pub_match DB\n'
                                                      '4: Update Scores\n'
                                                      '5: Update Cutoffs\n\n'
                             'Example call: python api_main.py --pipeline 0 4 5\n')
    parser.add_argument("--verbose", help='Toggle this if you want detailed print messages as the code runs.',
                        action="store_true")
    parser.add_argument("--scheduler", type=int, default=None, const=1, nargs='?', 
                        help='Toggle this if you want to run the scheduler program to execute tasks. Add an int after it to specify what the run_today value should be.')

    args = parser.parse_args()
    VERBOSE = args.verbose

    main(args)
