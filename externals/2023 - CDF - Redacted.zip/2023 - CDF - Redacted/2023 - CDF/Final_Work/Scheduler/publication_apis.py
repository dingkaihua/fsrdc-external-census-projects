import requests
import mysql.connector
from helper_funcs import *
from score_calculation import filter, preprocessing
import pandas
""" Variables BASE_ID and CORE_ID are defined in helper_funcs and used in publication_apis and api_main """
class All:
    # sends publication information to JQ Admin databases
    def sendToDBAll(self, db, project_id, results, hits, verbosity=False):
        mydb = mysql.connector.connect(
            host="metahost.census.gov",
            user="username",
            password="password",
            database="metadb"
        )

        mycursor = mydb.cursor()

        numPrint = 55
        if hits > 0:
            # print first 115 search results or all results if total is less than 115 115 is the limit for amount of
            # results Base will return at one time. If want more, need to retrieve results from specific pages of
            # results (see Base API documentation)
            # TODO (not actually a TODO just a note): If there is an index out of range error, they changed the
            #  max num of results. Debug and change accordingly
            if (hits < numPrint):
                numPrint = hits
            keywords = preprocessing(project_id)
            if verbosity:
                print(keywords)
            # Base
            if db == BASE_ID:

                for i in range(numPrint):
                    title = str(results[1]['response']['docs'][i].get('dctitle'))
                    authors = results[1]['response']['docs'][i].get('dcperson')
                    if results[1]['response']['docs'][i].get('dcdoi') is not None:
                        doi = results[1]['response']['docs'][i].get('dcdoi')[0]
                    else:
                        doi = "None"
                    if results[1]['response']['docs'][i].get('dcdate') is not None:
                        pub_year = str(results[1]['response']['docs'][i].get('dcdate')[:4])
                        pub_month = str(results[1]['response']['docs'][i].get('dcdate')[5:7])
                        pub_day = str(results[1]['response']['docs'][i].get('dcdate')[8:10])
                        if pub_month == '':
                            pub_month = "None"
                        if pub_day == '':
                            pub_day = "None"
                    else:
                        pub_year = "None"
                        pub_month = "None"
                        pub_day = "None"
                    if results[1]['response']['docs'][i].get('dcidentifier') is not None:
                        full_text_link = results[1]['response']['docs'][i].get('dcidentifier')[0]
                    else:
                        full_text_link = "None"
                    if results[1]['response']['docs'][i].get('dcpublisher') is not None:
                        publisher = results[1]['response']['docs'][i].get('dcpublisher')[0]
                    else:
                        publisher = "None"
                    abstract = str(results[1]['response']['docs'][i].get('dcdescription'))
                    doc_id = str(results[1]['response']['docs'][i].get('dcdocid'))
                    if results[1]['response']['docs'][i].get('dctype') is not None:
                        if len(results[1]['response']['docs'][i].get('dctype')) > 1:
                            final_type = ""
                            for j in range(len(results[1]['response']['docs'][i].get('dctype'))):
                                final_type += " " + results[1]['response']['docs'][i].get('dctype')[j]
                            pub_type = final_type
                        else:
                            pub_type = results[1]['response']['docs'][i].get('dctype')[0]
                    else:
                        pub_type = "None"

                    # query to grab all existing database entries that already have the same project_id and doc_id as
                    # entry you're about to add (duplicates)
                    # backticks around database bc it's a reserved word in SQL so need to clarify we're referring to the variable
                    sql_dup = f"SELECT * FROM api_pubs WHERE doc_id = '{doc_id}' AND project_id = {project_id} \
                    AND db_id = {db}"
                    mycursor.execute(sql_dup)
                    duplicates = mycursor.fetchall()

                    # if this doc_id doesn't already exist for this project_id, add it to database
                    if len(duplicates) == 0:

                        if filter(title, abstract, keywords):
                            val = tuple([project_id, db, doi, title, pub_year, pub_month, pub_day, publisher, abstract, pub_type,
                                   full_text_link, doc_id])
                            sql = f"INSERT INTO api_pubs (project_id, db_id, doi, title, pub_year, pub_month, pub_day, \
                            publisher, abstract, pub_type, full_text_link, doc_id) VALUES {val}"

                            mycursor.execute(sql)
                            pub_id = mycursor.lastrowid


                            mydb.commit()
                            if verbosity:
                                print(mycursor.rowcount, "record inserted.")

                            # if there are authors, insert all authors
                            if bool(authors):
                                for j in range(len(authors)):
                                    sql_part = "INSERT INTO api_pub_participants (pub_id, fullname) VALUES (%s, %s)"
                                    val_part = (pub_id, authors[j])
                                    mycursor.execute(sql_part, val_part)

                                    mydb.commit()

                        else:
                            if verbosity:
                                print('Preliminary score too low. Skipping insertion.')

                    # if this publication already exists in database, don't add again
                    else:
                        if verbosity:
                            print("duplicate value, not added")

            # Core
            if db == CORE_ID:
                for i in range(numPrint):

                    title = str(results[1]['data'][i]['_source']['title'])
                    if results[1]['data'][i]['_source']['doi'] is not None:
                        doi = results[1]['data'][i]['_source']['doi']
                    else:
                        doi = "None"
                    # work_id = str(results[1]['data'][i]['_id'])
                    author = results[1]['data'][i]['_source']['authors']
                    if str(results[1]['data'][i]['_source']['citations']) != '[]':
                        citations = str(results[1]['data'][i]['_source']['citations'])
                    else:
                        citations = "None"
                    contributors = results[1]['data'][i]['_source']['contributors']
                    if results[1]['data'][i]['_source']['datePublished'] is not None:
                        pub_year = str(results[1]['data'][i]['_source']['datePublished'])[:4]
                        pub_month = str(results[1]['data'][i]['_source']['datePublished'])[5:7]
                        pub_day = str(results[1]['data'][i]['_source']['datePublished'])[8:10]
                        if pub_month == '':
                            pub_month = "None"
                        if pub_day == '':
                            pub_day = "None"
                    else:
                        pub_year = "None"
                        pub_month = "None"
                        pub_day = "None"
                    if str(results[1]['data'][i]['_source']['topics']) != '[]':
                        topics = str(results[1]['data'][i]['_source']['topics'])
                    else:
                        topics = "None"
                    full_text = str(results[1]['data'][i]['_source']['fullText'])
                    full_text_link = str(results[1]['data'][i]['_source']['downloadUrl'])
                    publisher = str(results[1]['data'][i]['_source']['publisher'])
                    abstract = str(results[1]['data'][i]['_source']['description'])
                    doc_id = str(results[1]['data'][i]['_id'])

                    sql_dup = f"SELECT * FROM api_pubs WHERE doc_id = '{doc_id}' AND project_id = {project_id} \
                    AND db_id = {db}"
                    mycursor.execute(sql_dup)
                    duplicates = mycursor.fetchall()

                    # for dup in duplicates:

                    if len(duplicates) == 0:
                        if filter(title, abstract, keywords):
                            val = tuple(
                                [project_id, db, title, doi, pub_year, pub_month, pub_day, topics, citations, abstract,
                                full_text,
                                full_text_link, publisher, doc_id])
                            sql = f"INSERT INTO api_pubs (project_id, db_id, title, doi, pub_year, pub_month, pub_day, \
                            topics, citations, abstract, full_text, full_text_link, publisher, doc_id) \
                            VALUES {val}"


                            mycursor.execute(sql)
                            pub_id = mycursor.lastrowid


                            mydb.commit()
                            if verbosity:
                                print(mycursor.rowcount, "record inserted.")

                            # insert all authors into api_pub_participants
                            if bool(author):
                                for j in range(len(author)):
                                    val_part = tuple([pub_id, author[j]])
                                    sql_part = f"INSERT INTO api_pub_participants (pub_id, fullname) VALUES {val_part}"


                                    mycursor.execute(sql_part)

                                    mydb.commit()

                            # insert all contributors into api_pub_participants (Core has two separate fields-- authors and contributors)
                            if bool(contributors):
                                for j in range(len(contributors)):
                                    val_cont = tuple([pub_id, contributors[j]])
                                    sql_cont = f"INSERT INTO api_pub_participants (pub_id, fullname) VALUES {val_cont}"


                                    mycursor.execute(sql_cont)

                                    mydb.commit()


                        else:
                            if verbosity:
                                print('Preliminary score too low. Skipping insertion.')

                    else:
                        if verbosity:
                            print("duplicate value, not added")

            # change all "None" entries to null bc null takes up less space and makes for faster query times
            sql_update_year = "UPDATE api_pubs SET pub_year=NULL WHERE pub_year='None'"
            mycursor.execute(sql_update_year)
            mydb.commit()
            sql_update_month = "UPDATE api_pubs SET pub_month=NULL WHERE pub_month='None'"
            mycursor.execute(sql_update_month)
            mydb.commit()
            sql_update_day = "UPDATE api_pubs SET pub_day=NULL WHERE pub_day='None'"
            mycursor.execute(sql_update_day)
            mydb.commit()
            sql_update_doi = "UPDATE api_pubs SET doi=NULL WHERE doi='None'"
            mycursor.execute(sql_update_doi)
            mydb.commit()
            sql_update_title = "UPDATE api_pubs SET title=NULL WHERE title='None'"
            mycursor.execute(sql_update_title)
            mydb.commit()
            sql_update_link = "UPDATE api_pubs SET full_text_link=NULL WHERE full_text_link='None'"
            mycursor.execute(sql_update_link)
            mydb.commit()
            sql_update_publisher = "UPDATE api_pubs SET publisher=NULL WHERE publisher='None'"
            mycursor.execute(sql_update_publisher)
            mydb.commit()
            sql_update_abstract = "UPDATE api_pubs SET abstract=NULL WHERE abstract='None'"
            mycursor.execute(sql_update_abstract)
            mydb.commit()
            sql_update_id = "UPDATE api_pubs SET doc_id=NULL WHERE doc_id='None'"
            mycursor.execute(sql_update_id)
            mydb.commit()
            sql_update_type = "UPDATE api_pubs SET pub_type=NULL WHERE pub_type='None'"
            mycursor.execute(sql_update_type)
            mydb.commit()
            if verbosity:
                print(
                "changed None values to null in doi, title, year, month, pub_type, topics, citations, full text, full text link, publisher, abstract, doc id")

        else:
            if verbosity:
                print('No hits for this query')


# search Base API
class BaseSearch(All):

    def search(self, _path, project_id, _query):
        header = ["Accept: text/xml"]
        url = "https://api.base-search.net/cgi-bin/BaseHttpSearchInterface.fcgi"
        link = url + _path + "&query=" + _query + "&hits=125&format=json"
        request = requests.get(link, proxies={'https': '148.129.129.18:3128'})

        if (request.status_code == 200):
            data = [project_id, request.json()]
            return data

    def searchAll(self, project_id, _query):
        return self.search("?func=PerformSearch", project_id, _query)


# search Core API
class CoreSearch(All):

    def search(self, _path, project_id, _query):
        header = ["Accept: application/json", "apiKey=5WrCRw8MxOyjqd7Bpcaes4IvKPGg2otU"]
        url = "https://core.ac.uk:443/api-v2"
        request = requests.get(url + _path + _query + "?page=1&pageSize=125&" + header[1],
                               proxies={'https': '148.129.129.18:3128'})

        if (request.status_code == 200):
            data = [project_id, request.json()]
            return data

    def searchAll(self, project_id, _query):
        return self.search("/search/", project_id, _query)

