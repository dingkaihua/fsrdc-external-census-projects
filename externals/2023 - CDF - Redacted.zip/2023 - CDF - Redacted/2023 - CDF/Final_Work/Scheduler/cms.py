import mysql.connector

import requests

api_key = b"b5539e196fbe45cf07af9394ddb3cbcb67a6e097340b4ebf0c72667cb3171473"
headers = { 'Authorization' : 'key=%s' %  (api_key).decode("ascii") }

def connect():
    #connect to JQ Admin so we can create&modify databases on JQ Admin
    mydb = mysql.connector.connect(
    host="metahost.census.gov",
    user="username",
    password="password",
    database="metadb"
    )
    mycursor = mydb.cursor()

    #change the encoding of JQ Admin databases so it matches the way the API information is encoded
    sql = "SET collation_connection = 'utf8_general_ci'"
    mycursor.execute(sql)
    mydb.commit()
    sql1 = "ALTER TABLE api_pubs CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci"
    mycursor.execute(sql1)
    mydb.commit()

#sample url
#https://www.ces.census.gov/api/iaa/v1.3/project/status/CP?fields=cms_project_id,title&page=0&limit=10
#queries CMS database
def run_query(path, fields, page, limit):
    url = f'https://www.ces.census.gov/api/iaa/v1.3{path}?fields={fields}&page={page}&limit={limit}'
    request = requests.get(url, headers=headers, proxies={"https" : "148.129.75.18:3128"})
    if request.status_code == 200:
        return request.json()
    elif request.status_code == 204:
        return None
    else:
        raise Exception("Query failed to run by returning code of {}.".format(request.status_code))

#return project title and names of all the project's datasets based on its project id
def name_and_ds(proj_id):
    data = {}
    proj = run_query('/project/'+str(proj_id),'cms_project_id,title','0','10') # Execute the project query
    #'/project/status/CP'
    full = proj[0]['title']
    parts = full.split("-")
    #print(parts)
    data['title']= parts[2][1:]
    #if there's a '-' in the title, make sure to include it so return the full title
    if len(parts) > 3:
        for i in range(len(parts)-3):
            data['title']= data.get('title')+'-'+parts[3+i]
    #print(proj['cms_project_id'])
    datasets = run_query('/project/%s/data' % proj[0]['cms_project_id'],'name','0','10') # Execute the dataset query
    sets = []

    if datasets is not None:
        for ds in datasets:
            sets.append(ds['name'])

    data['datasets']=sets
    return data

#builds query url
def run_abstract_query(path,fields,page,limit):
    request = requests.get('https://www.ces.census.gov/api/iaa/v1.3%s?fields=%s&page=%s&limit=%s' % (path,fields,page,limit), headers=headers, proxies={"https" : "148.129.75.18:3128"})
    if request.status_code == 200:
        return request.json()
    else:
        raise Exception("Query failed to run by returning code of {}.".format(request.status_code))

#returns text of the project description corresponding to the given project id. If change "proposal" to
#"abstract", should return the abstract instead, which is shorter than description usually
def get_abstract(projid):
    results = run_abstract_query('/project/'+str(projid)+'/proposal/text','mime_data','0','10')
    #print(results)
    return results[0]['mime_data'].replace("\n", " ")


# return all authors with "researcher" role for a given project id (should correspond to all researchers who aren't Census employees)
def get_authors(pjid):
    projects = run_query('/project/' + str(pjid),
                         'cms_project_id,type_name,title,participants{username,fullname,roles}', '0',
                         '100')  # Execute the query

    auts = []

    for proj in projects:
        # print(proj['title'])
        if proj['title'].split("-")[0] == str(pjid) + " ":
            for part in proj['participants']:
                if 'researcher' in part['roles']:
                    auts.append(part['fullname'])

    return auts

