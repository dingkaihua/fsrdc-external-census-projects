from nltk.corpus import stopwords
import unicodedata
import string
import re
from nltk.stem import PorterStemmer
import nltk
import numpy as np
import pandas as pd
import mysql.connector
import math
pd.options.mode.chained_assignment = None

# Verbosity (do we want extra print/error statements)
VERBOSE = False

# Change these according to how the id's are defined in the api_pub_match database on JQAdmin
MANUAL_ID = 1
EDIT_ID = 2
BASE_ID = 3
CORE_ID = 4

# CURRENT MAX SCORE IS 100
AUT_WEIGHT = 40
COSINE_WEIGHT_ABS = 20
COSINE_WEIGHT_TITLE = 20

TITLE_WEIGHT = 10
ABSTRACT_WEIGHT = 10

def find_dupe_pubs(project_id: int, group_on: list):
    """ Helper Function """
    """ Given project_id, returns a list of duplicates based on what categories to group by """
    mydb = mysql.connector.connect(
        host="metahost.census.gov",
        user="username",
        password="password",
        database="metadb"
    )
    mycursor = mydb.cursor()
    sql_query = f"SELECT pub_id, db_id, title, score_total FROM api_pubs WHERE project_id={project_id}"
    mycursor.execute(sql_query)
    query_resp = mycursor.fetchall()

    # Creates a dataframe of all publications under a project_id
    lst = [[query_resp[i][0], query_resp[i][1], query_resp[i][2], query_resp[i][3]] for i in range(len(query_resp))]
    full_df = pd.DataFrame(lst, columns=['pub_id', 'db_id', 'title', 'score_total'])
    full_df.title = full_df.title.apply(clean_text)
    # Filters the dataframe based on duplicates
    data_groups = full_df.groupby(group_on)
    size = data_groups.size().reset_index()
    dupe_df = size[size[0] > 1]
    dupe_df.loc[:, 'title'] = dupe_df['title'].apply(clean_text)
    # Merges our full dataframe with our duplicated dataframe to get their pub_id
    merged_df = dupe_df.merge(full_df, on=group_on)
    merged_df = merged_df.rename(columns={0: 'num_dupes'})
    return merged_df

def find_dupes_to_remove(project_id: int):
    """ Uses the Helper Function above to group on title and db_id so we only remove within-db duplicates """
    merged_df = find_dupe_pubs(project_id, group_on=['title', 'db_id'])
    # Filters the dataframe and returns a list of (True, False) based on if it is a duplicate
    dupes = merged_df.rename(columns={0: 'num_dupes'}).duplicated(subset=['title', 'db_id']).to_list()
    # Final list of pub_ids of dupes
    dupe_ids = [merged_df.pub_id[i] for i in range(len(dupes)) if dupes[i]]

    return dupe_ids

def find_dupes_to_match(project_id: int):
    """ Uses the Helper Function above to group on title only so we can fill the match table with across-db duplicates"""
    merged_df = find_dupe_pubs(project_id, group_on=['title'])
    #Specify group_key behavior since this is changing in future pandas versions
    pub_id_df = pd.DataFrame(merged_df.groupby('title', group_keys=False)['pub_id'].apply(list)).reset_index()
    db_id_df = pd.DataFrame(merged_df.groupby('title', group_keys=False)['db_id'].apply(list)).reset_index()
    score_df = pd.DataFrame(merged_df.groupby('title', group_keys=False)['score_total'].apply(list)).reset_index()
    temp_df = pub_id_df.merge(db_id_df, on='title')
    temp_df = temp_df.merge(score_df, on='title')
    temp_dict = {}
    primary_db_dict = {}
    for i in range(len(temp_df)):
        row = temp_df.iloc[i]
        temp_dict[row.title] = {row.db_id[j]: row.pub_id[j] for j in range(len(row.db_id))}
        primary_db_dict[row.title] = row.db_id[np.argmax(row.score_total)]
    return temp_dict, primary_db_dict
def remove_dupes(project_id: int):
    """ Removes all title duplicates for a given project_id from api_pubs"""
    mydb = mysql.connector.connect(
        host="metahost.census.gov",
        user="username",
        password="password",
        database="metadb"
    )
    mycursor = mydb.cursor()
    dupe_ids = tuple(find_dupes_to_remove(project_id))
    print(f'{len(dupe_ids)} duplicates found.')
    if len(dupe_ids) != 0:
        #Mapping the str() function to every dupe_id in the tuple and then concatenating them all together as one large string
        dupe_ids_str = ", ".join(map(str, dupe_ids))
        sql_query = f"DELETE FROM api_pubs WHERE project_id={project_id}" \
                    f" AND pub_id in ({dupe_ids_str}) AND reviewed=0"
        mycursor.execute(sql_query)
def update_match_table(project_id, rem_dupes=True):
    """ Updates the api_pub_match table with duplicates across database pulls """
    # Remove within-db duplicates if they haven't already been removed prior
    if rem_dupes:
        remove_dupes(project_id)
    mydb = mysql.connector.connect(
        host="metahost.census.gov",
        user="username",
        password="password",
        database="metadb"
    )
    mycursor = mydb.cursor()
    match_dict, prim_db_dict = find_dupes_to_match(project_id)
    for title in match_dict.keys():
        if MANUAL_ID in match_dict[title]:
            manual_db_id = match_dict[title][MANUAL_ID]
            prim_id = 1
        else:
            manual_db_id = 0
            prim_id = prim_db_dict[title]
        base_id = match_dict[title][BASE_ID]


        if CORE_ID in match_dict[title]:
            core_id = match_dict[title][CORE_ID]
        else:
            core_id = None


        check_query = f"SELECT manual_pub_id FROM api_pub_match WHERE base_pub_id = {base_id}"
        if core_id is not None:
            check_query += f" AND core_pub_id = {core_id}"


        mycursor.execute(check_query)
        check_resp = mycursor.fetchall()


        if len(check_resp) == 0:
            # Construct a tuple of column names and their corresponding values.
            # Note that this will exclude 'core_pub_id' when its value is None.
            columns = ["title", "primary_db_id", "manual_pub_id", "base_pub_id"]
            values = [title, prim_id, manual_db_id, base_id]


            if core_id is not None:
                columns.append("core_pub_id")
                values.append(core_id)


            # Construct the SQL query string.
            columns_str = ', '.join(columns)
            placeholders_str = ', '.join(['%s'] * len(values))
            sql_query = f"INSERT INTO api_pub_match ({columns_str}) VALUES ({placeholders_str})"


            # Execute the SQL query with the value tuple.
            mycursor.execute(sql_query, values)
        elif ((check_resp[0][0] == 0) and manual_db_id > 0):
            sql_query = f"UPDATE api_pub_match SET manual_pub_id = {manual_db_id}, primary_db_id = 1 WHERE base_pub_id = {base_id}"
            if core_id is not None:
                sql_query += f" AND core_pub_id = {core_id}"
            mycursor.execute(sql_query)




def aut_queries(author: str):
    """given an author/researcher name, makes various formats of it to use as search queries for the APIs"""
    #final array to hold all the author queries we'll be running, without repeats
    aut_queries = []
    #max possible six versions of author's name, with repeats
    authors = []

    part = author.partition(' ')
    first = part[0]
    first_initial = first[0:1] + '.'
    if part[2].partition(' ')[2] == '':
        last = part[2].partition(' ')[0]
    else:
        middle = part[2].partition(' ')[0]
        middle_initial = middle[0:1] + '.'
        last = part[2].partition(' ')[2]
        aut5 = first_initial + ' ' + middle_initial + ' ' + last
        authors.append(aut5)
    #original author name provided
    aut1 = author
    #author name without middle name or initial
    aut2 = first + ' ' + last
    #if first, middle, or last name is just an initial, add a "." to the end
    #if first, middle, or last name is already an initial with a '.', get rid of the '.'
    #since queries are exact, sometimes 'J. James' returns different results from 'J James'
    if len(first) == 1:
        first = first+"."
    elif '.' in first:
        first = first.partition('.')[0]
    if part[2].partition(' ')[2] != '':
        if len(middle) == 1:
            middle = middle + "."
        elif '.' in middle:
            middle = middle.partition('.')[0]
    #queries with '.' added in where applicable
    aut3 = first + " " + last
    authors.append(aut1)
    authors.append(aut2)
    authors.append(aut3)
    if part[2].partition(' ')[2] != '':
        aut4 = first + " " + middle + " " + last
        authors.append(aut4)
    aut6 = first_initial + " " + last
    authors.append(aut6)
    #get rid of duplicate queries between the 4 different versions
    for i in range(len(authors)):
        if authors[i] not in aut_queries:
            aut_queries.append(authors[i])
    #print(queries)
    return aut_queries

def preprocess_text(text: str):


    # converts text to tokens
    def tokenization(text):
        tokens = nltk.word_tokenize(text)
        return tokens

    STOPWORDS = stopwords.words('english')

    def remove_stopwords(tokens):
        filtered_tokens = [token for token in tokens if token not in STOPWORDS]
        return filtered_tokens

    ps = PorterStemmer()

    def stem(words):
        stemmed_tokens = [ps.stem(word) for word in words]
        return stemmed_tokens

    from nltk.stem.wordnet import WordNetLemmatizer

    lemmatizer = WordNetLemmatizer()

    def lemmatize(words):
        lemmatized_tokens = [lemmatizer.lemmatize(word) for word in words]
        return lemmatized_tokens

    def refactor(words):
        return ' '.join(words)
    # ONE PIPELINE FOR ALL STEPS (find individual functions in helper_funcs.py)
    return refactor(lemmatize(remove_stopwords(tokenization(clean_text(text)))))

def clean_text(text: str):
    # Remove accented chars
    text = unicodedata.normalize('NFKD', str(text)).encode('ascii', 'ignore').decode('utf-8', 'ignore')

    pattern = r'[^a-zA-Z\s]'
    n_pattern = r'[^a-zA-Z0-9\s]'
    # Removing everything apart from alphanumerical chars
    text = re.sub(pattern, '', text)

    # Removing numbers
    text = re.sub(n_pattern, '', text)

    # Remove punctuation
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = re.sub('[''""…]', '', text)
    text = re.sub('\n', '', text)

    # converts to lower case
    return text.lower().strip()
def query_resp_to_df(query_resp, cols=None):
    return pd.DataFrame(query_resp, columns=cols)

def update_cutoffs(project_id):
    """ Calculates the high and low cutoffs for a given project based on the reviewed publications """
    mydb = mysql.connector.connect(
        host="metahost.census.gov",
        user="username",
        password="password",
        database="metadb"
    )
    mycursor = mydb.cursor()
    # Grabs the reviewed publications for a given project from the TruthDeck CSV file (deprecated)
    # truth_deck = pd.read_csv('../ResearchOutputs.csv')
    # truth_deck['OutputTitle'] = truth_deck['OutputTitle'].apply(preprocess_text)
    # truth_deck = truth_deck.rename(columns={'OutputTitle': 'title'})
    # truth_deck_pjid = truth_deck[truth_deck['ProjectID'] == project_id]

    # Grabs all publications that have been reviewed to add to the truth deck
    sql_query = f"SELECT title FROM api_pubs WHERE reviewed > 0 and project_id={project_id}"
    mycursor.execute(sql_query)
    query_resp = mycursor.fetchall()
    columns = ['title']
    reviewed_pubs = query_resp_to_df(query_resp, columns)
    reviewed_pubs['title'] = reviewed_pubs['title'].apply(preprocess_text)


    # Grabs all the relevant publications from the api_pubs database
    remove_dupes(project_id)
    sql_query = f"SELECT pub_id, db_id, title, score_total, score_auth, score_title, score_abstract \
            FROM api_pubs WHERE project_id={project_id}"
    mycursor.execute(sql_query)
    query_resp = mycursor.fetchall()
    columns = ['pub_id', 'db_id', 'title', 'score_total', 'score_auth', 'score_title', 'score_abstract']
    api_pubs_df = query_resp_to_df(query_resp, columns)
    api_pubs_df['title'] = api_pubs_df['title'].apply(preprocess_text)


    # Performs a left-join on the truth-deck titles (to get scores for all reviewed publications)
    merged_df = pd.merge(reviewed_pubs, api_pubs_df, on='title')
    merged_df = merged_df.drop_duplicates(subset=['pub_id'])


    def calc_cutoffs(column_title, max_high = 100, min_low = 0):
        "Helper Function to Calculate Cutoffs"
        # Default to the cutoffs created using only api_pubs

        if api_pubs_df[column_title].dropna().empty:
            high_cutoff = max_high
            low_cutoff = min_low
        else:
            stdev = api_pubs_df[column_title].std()
            median_val = api_pubs_df[column_title].median()
            high_cutoff = median_val + (2 * stdev)
            low_cutoff = median_val + (0.5 * stdev)

        if (len(merged_df) > 0):
            truth_deck_val = merged_df[column_title].quantile(0.25)
            high_cutoff = (truth_deck_val + high_cutoff) / 1.25

        high_cutoff = min(high_cutoff, max_high)
        low_cutoff = max(low_cutoff, min_low)
        return float(high_cutoff), float(low_cutoff)
    total_high, total_low = calc_cutoffs('score_total', 100, 0)
    auth_high, auth_low = calc_cutoffs('score_auth', AUT_WEIGHT, 0)
    title_high, title_low = calc_cutoffs('score_title', COSINE_WEIGHT_TITLE + TITLE_WEIGHT, 0)
    abstract_high, abstract_low = calc_cutoffs('score_abstract', COSINE_WEIGHT_ABS + ABSTRACT_WEIGHT, 0)

    if pd.isna(total_high):
        total_high = 100
    if pd.isna(total_low):
        total_low = 0
    if pd.isna(auth_high):
        auth_high = 100
    if pd.isna(auth_low):
        auth_low = 0
    if pd.isna(title_high):
        title_high = 100
    if pd.isna(title_low):
        title_low = 0
    if pd.isna(abstract_high):
        abstract_high = 100
    if pd.isna(abstract_low):
        abstract_low = 0

    exists_query = f"SELECT distinct project_id from api_pub_cutoff"
    mycursor.execute(exists_query)
    exists_resp = mycursor.fetchall()
    exists_lst = [exists_resp[i][0] for i in range(len(exists_resp))]
    exists = project_id in exists_lst

    # if exists:
    #     # update

    #     update_query = f"UPDATE api_pub_cutoff SET total_high = %s, total_low = %s," \
    #                    f"auth_high = %s, auth_low = %s," \
    #                    f"title_high = %s, title_low = %s," \
    #                    f"abstract_high = %s, abstract_low = %s " \
    #                f"WHERE project_id = %s"
    #     vals = {total_high, total_low, auth_high, auth_low, title_high, title_low, abstract_high, abstract_low, project_id}
    #     mycursor.execute(update_query)



    # else:
        
    #     insert_query = f"INSERT INTO api_pub_cutoff (project_id, total_high, total_low," \
    #                    f"auth_high, auth_low," \
    #                    f"title_high, title_low," \
    #                    f"abstract_high, abstract_low) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
    #     vals = (project_id, total_high, total_low, auth_high, auth_low, title_high, title_low, abstract_high, abstract_low)
    #     mycursor.execute(insert_query, vals)

    if exists:
        # update
        update_query = "UPDATE api_pub_cutoff SET total_high = %s, total_low = %s," \
                    "auth_high = %s, auth_low = %s," \
                    "title_high = %s, title_low = %s," \
                    "abstract_high = %s, abstract_low = %s " \
                    "WHERE project_id = %s"
        vals = (total_high, total_low, auth_high, auth_low, title_high, title_low, abstract_high, abstract_low, project_id)
        mycursor.execute(update_query, vals)
    else:
        insert_query = "INSERT INTO api_pub_cutoff (project_id, total_high, total_low," \
                    "auth_high, auth_low," \
                    "title_high, title_low," \
                    "abstract_high, abstract_low) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
        vals = (project_id, total_high, total_low, auth_high, auth_low, title_high, title_low, abstract_high, abstract_low)
        mycursor.execute(insert_query, vals)

    print('Updated Cutoffs!')




