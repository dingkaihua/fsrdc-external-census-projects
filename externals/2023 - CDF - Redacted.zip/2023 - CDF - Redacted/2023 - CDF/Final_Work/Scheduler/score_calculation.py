
from nltk.tokenize import word_tokenize
from helper_funcs import *
from cms import *
import pandas as pd

from sklearn.feature_extraction.text import CountVectorizer

mydb = mysql.connector.connect(
    host="metahost.census.gov",
    user="username",
    password="password",
    database="metadb"
)
mycursor = mydb.cursor()
# dictionary of how many hits each query gets
data = {}

# keys are pub_id, values are the associated score
rows = {}

# of points per pub_id (a unique ID given to each publication) for each pjid
res_pubs = {}
# of points assigned to publications from each of the 5 queries (publication year, authors, NLP title, NLP abstract, datasets). PJID is key, value is array with 5 entries
matches = {}
# parameters used to assign points to publications, for the user's reference if they want to see the NLP search words used, or any of the other metadata
params = {}

nlp_data = []
nlp_res = {}
nlp_matches = {}




def preprocessing(pjid):
    """ Takes in pjid and returns keywords to pass as arguments into other functions when scoring"""
    title = name_and_ds(pjid)['title']  # returns the title of a given project from CMS (using its project id)
    description = title + ' ' + get_abstract(pjid)
    # tokenizing words and getting rid of stop words
    descrip = word_tokenize(description)
    stop_words = set(stopwords.words("english"))

    # list with each description word as an entry, and stopwords removed
    filtered_list = [
        word for word in descrip if word.casefold() not in stop_words]

    # giving each word a part-of-speech tag
    descrip_pos = nltk.pos_tag(descrip)

    def chunk():
        # chunking-- looking for phrases with a specific format
        # find noun phrase that starts w/any # adjs, and ends w/any # nouns
        grammar = "NP: {<JJ>*<NN>*}"
        chunk_parser = nltk.RegexpParser(grammar)
        # make a tree out of the chunks
        tree = chunk_parser.parse(descrip_pos)
        # temp array to store all chunks/phrases of a set size
        phrase = []
        # stores all the phrases, key indexed by the # of words in the phrase
        chunks = {}
        for s in tree.subtrees(filter=lambda tree: tree.label() == 'NP'):
            # print([x[0] for x in s.leaves()])
            for x in s.leaves():
                phrase.append(x[0])
            # print(phrase)
            size = len(phrase)
            full = ""
            # format each noun phrase so that each word is separated by a space
            for i in range(size):
                if full == "":
                    full = phrase[i]
                else:
                    full = full + " " + phrase[i]
            # add phrase to the dictionary under the key value that equals the size of the phrase
            if chunks.get(str(size)) is not None:
                chunks.get(str(size)).append(full)
            else:
                chunks[str(size)] = [full]
            phrase = []
        return chunks

    def freq_dist():
        # frequency distribution
        # stores up to the top 20 most frequent words in the description
        from nltk import \
            FreqDist  # without this import statement, it thinks FreqDist is a variable, even though this package was imported in a previous code block
        freq_words = []
        frequency_distribution = FreqDist(filtered_list)
        most_common_words = frequency_distribution.most_common(20)
        # print(frequency_distribution.most_common(20))
        for i in range(min(len(most_common_words), 20)):
            word = most_common_words[i][0]
            # if a punctuation mark or article is in the top 20, don't add it to the list
            if len(word) == 1:
                continue
            else:
                freq_words.append(word)
        return freq_words

    def ngrams():
        # ngrams, groups of n words
        from nltk import ngrams, FreqDist
        all_ngrams = {}
        # dictionary where keys are number of words in phrase, and values are the phrases
        all_counts = {}
        for size in 2, 3, 4, 5:
            all_counts[size] = FreqDist(ngrams(filtered_list, size))
        # print(all_counts[2].most_common(5))
        third = ''
        fourth = ''
        fifth = ''
        # get five most ngrams for n= 2,3,4,5
        for i in range(4):
            most_common_grams = all_counts[i+2].most_common(5)
            for j in range(min(5, len(most_common_grams))):
                # first and second words in ngram
                first = most_common_grams[j][0][0]
                second = most_common_grams[j][0][1]
                if i + 2 == 2:
                    # if at least one of the words is only one character (most likely a punctuation mark), don't add ngram to dictionary
                    if len(first) == 1 or len(second) == 1:
                        continue
                    if all_ngrams.get(str(i + 2)) is not None:
                        all_ngrams[str(i + 2)] = all_ngrams.get(str(i + 2)).append(first + " " + second)
                    else:
                        all_ngrams[str(i + 2)] = [first + " " + second]
        return all_ngrams

    all_ngrams = ngrams()
    chunks = chunk()
    freq_words = freq_dist()
    # final array of all the keywords we'll be searching for in the publication database (api_base)
    keywords = []
    # add all ngrams where n=2 (once n gets to be >2 the ngrams aren't as coherent because we're missing articles, conjunctions, etc)
    if all_ngrams.get("2") is not None:
        keywords += all_ngrams.get("2")
    # add noun phrases of lengths 2 and 3
    if chunks.get("2") is not None:
        keywords += chunks.get("2")
    if chunks.get("3") is not None:
        keywords += chunks.get("3")
    # add most freq words
    if len(freq_words) > 0:
        keywords += freq_words
    keywords = (map(lambda x: x.lower(), keywords))
    # gets rid of duplicate words or phrases
    keywords = list(set(keywords))

    return keywords

def basic_calculation(pjid, year, keywords):
    '''Returns a score based on author and publication year match
    Only takes into account researchers on the publication. i.e. 5 total researchers but 3 belong to the research project
    = a score of 3/5 * author_weight (defined above)
    '''

    # keys are the names of all the authors/researchers for this project, values are the variations on their names to search
    authors = {}

    auts = get_authors(pjid)  # array of all those listed as researcher in CMS
    numAuts = len(auts)
    # for each author, split into multiple search queries, as we did before
    for i in range(numAuts):
        authors[i] = aut_queries(auts[i])

    ds = name_and_ds(pjid)['datasets']  # array

    # contains search queries for this specific project_id
    params_inner = {}
    # maximum possible score a publication can have
    max_score = 1 + numAuts  # pub_year point plus number of authors

    params_inner['year'] = year
    params_inner['authors'] = auts
    params_inner['datasets'] = ds
    params_inner['keywords'] = keywords
    params[pjid] = params_inner

    # add all publications with a feasible publication year (or null pub year value) to dictionary
    '''pub_year'''

    q1 = f"SELECT * FROM api_pubs WHERE project_id= {pjid} AND (pub_year >= {year} OR pub_year is NULL)"
    mycursor.execute(q1)
    r1 = mycursor.fetchall()
    data['pub year'] = len(r1)
    for i in range(len(r1)):
        rows[r1[i][0]] = 1

    '''authors'''
    aut_hits = 0

    def refineAut(pjid, authors):
        q2 = f"SELECT A.pub_id, P.project_id, A.fullname FROM api_pub_participants A LEFT JOIN api_pubs P on \
        A.pub_id = P.pub_id WHERE P.project_id= %s AND (A.fullname LIKE %s"
        d2 = (pjid, str(('%' + authors[0] + '%')))
        l2 = list(d2)
        numData = len(authors)
        if numData == 1:
            q2 += ")"
        else:
            for j in range(numData - 1):
                q2 += " OR A.fullname LIKE %s"
                if j == numData - 2:
                    q2 += ")"
                l2.append(str(('%' + authors[j + 1] + '%')))
        d2 = tuple(l2)
        test_join = "% OR A.fullname LIKE %".join(authors)
        qtest = f"SELECT A.pub_id, P.project_id, A.fullname FROM api_pub_participants A LEFT JOIN api_pubs P on \
        A.pub_id = P.pub_id WHERE P.project_id= {pjid} AND (A.fullname LIKE %{test_join}%)"
        mycursor.execute(q2, d2)
        r2 = mycursor.fetchall()
        temp_set = []
        for i in range(len(r2)):
            temp_set.append(r2[i][0])
        temp_set = list(set(temp_set))
        # get one point for each version of an author's name present (should just be max 1 point possible)
        for i in range(len(temp_set)):
            if rows.get(temp_set[i]) is not None:
                rows[temp_set[i]] = rows.get(temp_set[i]) + 1
        return len(temp_set)

    # calculates total points received from all author names the publication has
    for i in range(numAuts):
        aut_hits += refineAut(pjid, authors.get(i))

    data['author'] = aut_hits

    # entries that don't have any of the correct authors will have scores ending in 0.0001
    for key in rows.keys():
        if rows.get(key) == 1:
            rows[key] = 1
        else:
            rows[key] = float(AUT_WEIGHT * (rows[key] / max_score))  # normalize each value to be between 0 and 1
    return rows

def kw_in_abstract(pjid, keywords):
    '''Matches keywords (taken from preprocessing function) in publication abstract'''
    nlp_rows = {}
    q3 = "SELECT pub_id, abstract FROM api_pubs WHERE project_id= %s AND (abstract LIKE %s"
    d3 = (pjid, str('%' + keywords[0] + '%'))
    l3 = list(d3)
    numData = len(keywords)
    # add all nlp keywords to search query
    if numData == 1:
        q3 += ")"
    else:
        for i in range(numData - 1):
            q3 += " OR abstract LIKE %s"
            if i == numData - 2:
                q3 += ")"
            # 'like' keyword and % means will get a point as long as keyword is in text, with any characters before and after it
            l3.append(str('%' + keywords[i + 1] + '%'))
    d3 = tuple(l3)
    mycursor.execute(q3, d3)
    r3 = mycursor.fetchall()
    nlp_data.append(len(r3))  # amount of hits that have at least one matching word
    # for each publication that has at least one matching word, give a point for each matching word
    descrips = {}
    for i in range(len(r3)):
        if nlp_rows.get(r3[i][0]) is not None:
            nlp_rows[r3[i][0]] = nlp_rows.get(r3[i][0]) + 1
        else:
            nlp_rows[r3[i][0]] = 1
            descrips[r3[i][0]] = r3[i][1].decode()

    # total points assigned to all publications from q3
    descrip_hits = 0
    # giving one additional point to the publication for each word it has
    for i in range(len(keywords)):
        for key in descrips.keys():
            if descrips[key] is not None:
                if keywords[i] in descrips[key].lower():
                    if nlp_rows[key] is not None:
                        nlp_rows[key] = nlp_rows[key] + 1
                        descrip_hits += 1

    data['NLP description'] = descrip_hits
    if nlp_rows:
        max_score_given = max(nlp_rows.values())
    else:
        max_score_given = 0
    for key in nlp_rows.keys():
        if nlp_rows.get(key) == 1:
            nlp_rows[key] = 1
        else:
            nlp_rows[key] = float(ABSTRACT_WEIGHT * (nlp_rows[key] / max_score_given))
    return nlp_rows

def kw_in_title(pjid, keywords):
    '''Matches keywords (taken from preprocessing function) in publication title'''
    nlp_rows = {}
    q4 = "SELECT pub_id, title FROM api_pubs WHERE project_id= %s AND (title LIKE %s"
    d4 = (pjid, str('%' + keywords[0] + '%'))
    l4 = list(d4)
    numData = len(keywords)
    if numData == 1:
        q4 += ")"
    else:
        for i in range(numData - 1):
            q4 += " OR title LIKE %s"
            if i == numData - 2:
                q4 += ")"
            l4.append(str('%' + keywords[i + 1] + '%'))
    d4 = tuple(l4)
    mycursor.execute(q4, d4)
    r4 = mycursor.fetchall()

    nlp_data.append(len(r4))  # amount of hits with at least one matching word
    descrips = {}
    for i in range(len(r4)):
        if nlp_rows.get(r4[i][0]) is not None:
            print('will this even be run????')
            nlp_rows[r4[i][0]] = nlp_rows.get(r4[i][0]) + 1
        else:
            nlp_rows[r4[i][0]] = 0
            descrips[r4[i][0]] = r4[i][1]

    # max_score += 2 + 2 * numData  # max # of points a publication can get from queries 3 and 4
    # total points assigned to all publications from q4
    title_hits = 0
    # giving one additional point to the publication for each word it has
    for i in range(len(keywords)):
        for key in nlp_rows.keys():
            if descrips[key] is not None:
                if keywords[i] in descrips[key].lower():
                    if nlp_rows[key] is not None:
                        nlp_rows[key] = nlp_rows[key] + 1
                        title_hits += 1
    data['NLP title'] = title_hits
    if nlp_rows:
        max_score_given = max(nlp_rows.values())
    else:
        max_score_given = 0
    #max_score_given = max(list(nlp_rows.values())) if nlp_rows else 0
    for key in nlp_rows.keys():
        if nlp_rows.get(key) == 1:
            nlp_rows[key] = 1
        else:
            nlp_rows[key] = float(TITLE_WEIGHT * (nlp_rows[key] / max_score_given))
    return nlp_rows

def update_score(project_id):
    """ Updates all publication scores under the given project_id"""
    keywords = preprocessing(project_id)
    author_score = basic_calculation(project_id, 2000, keywords)
    print('Author Score Calculated')
    title_cos_score = cos_similarity(project_id, COSINE_WEIGHT_TITLE, abstract_use=False)
    title_kw_score = kw_in_title(project_id, keywords)
    print('Title Score Calculated')
    abstract_cos_score = cos_similarity(project_id, COSINE_WEIGHT_ABS, abstract_use=True)
    abstract_kw_score = kw_in_abstract(project_id, keywords)
    print('Abstract Score Calculated')
    score_other = misc_score_calc(project_id)
    print('Score Other Calculated')
    total_score = {}
    for key in score_other.keys():
        if key not in author_score:
            author_score[key] = 1
        if key not in title_cos_score:
            title_cos_score[key] = 1
        if key not in abstract_cos_score:
            abstract_cos_score[key] = 1
        if key not in title_kw_score:
            title_kw_score[key] = 1
        if key not in abstract_kw_score:
            abstract_kw_score[key] = 1
        total_score[key] = abstract_cos_score[key] + abstract_kw_score[key] + \
                           title_cos_score[key] + title_kw_score[key] + \
                           author_score[key] + score_other[key]
    # update scores in api_pubs
    for key in total_score.keys():
        qu = f"UPDATE api_pubs SET score_total= {float(total_score[key])}, score_auth = {float(author_score[key])},\
             score_title = {float(title_cos_score[key] + title_kw_score[key])}, \
             score_abstract = {float(abstract_cos_score[key] + abstract_kw_score[key])}, \
             score_other = {float(score_other[key])} \
            WHERE pub_id = {key} AND project_id = {project_id}"
        mycursor.execute(qu)

def cos_similarity(project_id, weight, abstract_use=True):
    """ Finds the cosine similarity between the project abstract/title and all of its associated publications

    To debug: I recommend debugging each block separately in Jupyter Notebook. Makes life easier :)
    """
    count_vect = CountVectorizer(min_df=0., max_df=1., decode_error='ignore')
    from sklearn.metrics.pairwise import cosine_similarity

    # Grabs project information from CMS
    proj_title = name_and_ds(project_id)['title']
    proj_abs = get_abstract(project_id)

    # Grabs associated publications from api_pubs
    sql_query = f"SELECT pub_id, title, abstract FROM api_pubs WHERE project_id={project_id}"
    mycursor.execute(sql_query)
    query_resp = mycursor.fetchall()

    # If we use abstract, we grab pubs where abstract exists. Otherwise grab pubs where title exists.
    if abstract_use:
        all_pubs = [[query_resp[i][0], query_resp[i][1], query_resp[i][2].decode()] for i in range(len(query_resp)) if
                    query_resp[i][2] is not None]
    else:
        all_pubs = [[query_resp[i][0], query_resp[i][1], query_resp[i][2]] for i in range(len(query_resp)) if
                    query_resp[i][1] is not None]
    all_pubs_df = pd.DataFrame(all_pubs, columns=['pub_id', 'title', 'abstract'])

    # Sets the last index to be the research project (to compare all publications to)
    all_pubs_df.loc[len(all_pubs_df.index)] = [0, proj_title, proj_abs]
    if abstract_use:
        corpus = all_pubs_df['abstract'].to_list()
    else:
        corpus = all_pubs_df['title'].to_list()
    process_corpus = np.vectorize(preprocess_text)
    processed_corpus = process_corpus(corpus)

    if not any(processed_corpus):
        return {}

    # Creates a similarity matrix from the processed corpus
    count_vect_matrix = count_vect.fit_transform(processed_corpus)
    count_vect_matrix = count_vect_matrix.toarray()
    count_doc_sim = cosine_similarity(count_vect_matrix)

    # Let us create a dataframe out of this matrix for easy retrieval of data
    count_doc_sim_df = pd.DataFrame(count_doc_sim)

    # Grabs the similarity scores for the research project
    abs_similarities = count_doc_sim_df.iloc[len(all_pubs_df.index) - 1].values
    all_pubs_df['cosine_scores'] = abs_similarities
    rows = dict(zip(all_pubs_df.pub_id.to_list(), all_pubs_df.cosine_scores.to_list()))
    #print(rows.values())

    try:
        if rows:
            max_score_given = max(rows.values())
        else:
            max_score_given = 0
        #max_score_given = max(list(rows.values())[:-1]) if rows else 0
    except Exception as e:
        print(f'ERROR ERROR: {str(e)}')

    for key in rows.keys():
        if max_score_given != 0:
            curr_score = weight * (rows[key] / max_score_given)
        else:
            curr_score = 0
        if curr_score == 0:
            rows[key] = 1
        else:
            rows[key] = float(curr_score)
    return rows

def misc_score_calc(project_id):
    """ Scores a publication based on if it has text link (+2), pub year (+1), publisher (+1), doi (+1) """
    # Grabs associated publications from api_pubs
    sql_query = f"SELECT pub_id, full_text_link, pub_year, publisher, doi FROM api_pubs WHERE project_id={project_id}"
    mycursor.execute(sql_query)
    query_resp = mycursor.fetchall()
    rows = {}
    # A little for loop that maps each pub_id to its given score_other
    # Bit tedious, I know, but the list comprehension for this was ugly and I wanted readability :P
    for i in range(len(query_resp)):
        def isnone(elements, weights=[2, 1, 1, 1]):
            total = 0
            for j in range(len(elements)):
                if elements[j] is not None:
                    total += weights[j]
            return total

        rows[query_resp[i][0]] = isnone(query_resp[i][1:5])
    return rows

def filter(title: str, abstract: str, keywords: str):
    """Returns a quick preliminary score to filter out bad publications"""
    threshold = 0.005
    complete_str = title + " " + abstract
    total_score = 0
    possible_score = len(keywords)
    for i in range(len(keywords)):
        if keywords[i] in complete_str.lower():
            total_score += 1

    return (total_score / possible_score) >= threshold

def main():
    update_score(5)


if __name__ == '__main__':
    main()